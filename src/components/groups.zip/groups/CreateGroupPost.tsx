// src/components/group/CreateGroupPost.tsx
import React, { useState, useRef } from 'react';
import { useGroupPosts } from '@/contexts/GroupPostsContext';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { ImageIcon, VideoIcon, Loader2, X } from 'lucide-react';
import { Input } from '@/components/ui/input';

export function CreateGroupPost() {
  const { addPost } = useGroupPosts();
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const imageRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);

  const handleFilePreview = (
    files: FileList | null,
    setter: React.Dispatch<React.SetStateAction<string[]>>,
    extractor: (file: File) => string
  ) => {
    if (!files) return;
    const urls = Array.from(files).map(extractor);
    setter(prev => [...prev, ...urls]);
  };

  const clearPreviews = () => {
    setImages([]);
    setVideos([]);
    if (imageRef.current) imageRef.current.value = '';
    if (videoRef.current) videoRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && images.length === 0 && videos.length === 0) return;

    setIsSubmitting(true);
    try {
      // gather actual File objects
      const files: File[] = [];
      if (imageRef.current?.files) files.push(...Array.from(imageRef.current.files));
      if (videoRef.current?.files) files.push(...Array.from(videoRef.current.files));

      await addPost(content, files);
      setContent('');
      clearPreviews();
    } catch (err) {
      console.error('Failed to post to group:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <Textarea
        placeholder="Write something to your group..."
        value={content}
        onChange={e => setContent(e.target.value)}
        className="w-full resize-none focus-visible:ring-[#1877F2]"
        rows={3}
      />

      {/* previews */}
      {(images.length > 0 || videos.length > 0) && (
        <div className="grid grid-cols-2 gap-2">
          {images.map((src, i) => (
            <div key={i} className="relative rounded-md overflow-hidden">
              <img src={src} className="w-full h-24 object-cover" alt="" />
              <Button
                size="icon"
                variant="destructive"
                className="absolute top-1 right-1 h-6 w-6 p-1"
                onClick={() => setImages(imgs => imgs.filter((_, idx) => idx !== i))}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
          {videos.map((src, i) => (
            <div key={i} className="relative rounded-md overflow-hidden">
              <video src={src} controls className="w-full h-24 object-cover" />
              <Button
                size="icon"
                variant="destructive"
                className="absolute top-1 right-1 h-6 w-6 p-1"
                onClick={() => setVideos(vids => vids.filter((_, idx) => idx !== i))}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex items-center justify-between">
        {/* file inputs */}
        <div className="flex space-x-2">
          <Input
            ref={imageRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={e => handleFilePreview(e.target.files, setImages, file => URL.createObjectURL(file))}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => imageRef.current?.click()}
            disabled={isSubmitting}
            className="flex items-center text-gray-600"
          >
            <ImageIcon className="h-4 w-4 mr-1 text-green-500" /> Image
          </Button>

          <Input
            ref={videoRef}
            type="file"
            accept="video/*"
            multiple
            className="hidden"
            onChange={e => handleFilePreview(e.target.files, setVideos, file => URL.createObjectURL(file))}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => videoRef.current?.click()}
            disabled={isSubmitting}
            className="flex items-center text-gray-600"
          >
            <VideoIcon className="h-4 w-4 mr-1 text-red-500" /> Video
          </Button>
        </div>

        <Button
          type="submit"
          disabled={isSubmitting || (!content.trim() && images.length + videos.length === 0)}
          className="bg-[#1877F2] hover:bg-[#166FE5] text-white"
        >
          {isSubmitting
            ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Posting...
              </>
            )
            : 'Post'}
        </Button>
      </form>
    </div>
  );
}
