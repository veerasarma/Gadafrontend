import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useGroups } from '@/contexts/GroupContext';
import { Users, Plus, Check } from 'lucide-react';

export function GroupsSidebar() {
  const { myGroups, discover, joinLeave } = useGroups();
  return (
    <div className="bg-white p-4 border-r border-gray-200 h-full overflow-auto space-y-6">
      <div>
        <h3 className="text-xs font-semibold text-gray-400 uppercase mb-2">
          My Groups
        </h3>
        <ul className="space-y-2">
          {myGroups.map(g => (
            <li key={g.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-gray-500" />
                <Link
                  to={`/groups/${g.id}`}
                  className="text-sm text-gray-800 hover:underline"
                >
                  {g.name}
                </Link>
                {/* <span className="text-sm font-medium">{g.name}</span> */}
              </div>
              <button
                onClick={()=>joinLeave(g.id)}
                className="text-xs text-purple-600 hover:underline"
              >
                Leave
              </button>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h3 className="text-xs font-semibold text-gray-400 uppercase mb-2">
          Discover
        </h3>
        <ul className="space-y-2">
          {discover.map(g => (
            <li key={g.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-gray-500" />
                <Link
                  to={`/groups/${g.id}`}
                  className="text-sm font-medium text-gray-800 hover:underline"
                >
                  {g.name}
                </Link>
                {/* <span className="text-sm">{g.name}</span> */}
              </div>
              <button
                onClick={()=>joinLeave(g.id)}
                className="text-xs text-green-600 hover:underline"
              >
                Join
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}


