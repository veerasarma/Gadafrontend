import React, { useState } from 'react';
import { SimpleModal } from '@/components/ui/SimpleModal';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useGroups } from '@/contexts/GroupContext';

export function CreateGroupModal({ isOpen, onClose }) {
  const { addGroup } = useGroups();
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');

  const handleCreate = async () => {
    await addGroup({ name, description: desc });
    setName(''); setDesc('');
    onClose();
  };

  return (
    <SimpleModal isOpen={isOpen} onClose={onClose}>
      <h2 className="text-lg font-medium mb-4">Create Group</h2>
      <Input
        placeholder="Group name"
        value={name}
        onChange={e=>setName(e.target.value)}
        className="mb-3"
      />
      <Textarea
        placeholder="Description"
        value={desc}
        onChange={e=>setDesc(e.target.value)}
        rows={3}
      />
      <div className="mt-4 flex justify-end">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleCreate} disabled={!name.trim()}>
          Create
        </Button>
      </div>
    </SimpleModal>
  );
}
