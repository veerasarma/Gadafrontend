import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ThumbsUp, MessageSquare, Send } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useGroupPosts } from '@/contexts/GroupPostsContext';
import { formatDate } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import type { GroupPost } from '@/services/groupService';

interface Props {
  post: GroupPost;
}

export function GroupPostItem({ post }: Props) {
  const { user } = useAuth();
  const { likePost, commentPost } = useGroupPosts();
  const [comment, setComment] = useState('');
  const [showComments, setShowComments] = useState(false);

  const liked = user ? post.likes.some(l => l.userId === user.id) : false;

  const handleLike = () => {
    if (!user) return;
    likePost(post.id);
  };

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !comment.trim()) return;
    commentPost(post.id, comment);
    setComment('');
  };

  const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <Card className="mb-4">
      <CardHeader className="p-4 pb-0 flex items-start">
        <div className="flex-1 flex items-center space-x-3">
          <Link to={`/profile/${post.author.id}`}>
            <Avatar>
              {post.author.username ? (
                <AvatarFallback>{getInitials(post.author.username)}</AvatarFallback>
              ) : null}
            </Avatar>
          </Link>
          <div>
            <Link to={`/profile/${post.author.id}`} className="font-semibold hover:underline">
              {post.author.username}
            </Link>
            <p className="text-sm text-gray-500">{formatDate(post.createdAt)}</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-4">
        {post.content && <p className="mb-3 whitespace-pre-line">{post.content}</p>}

        {post.images.length > 0 && (
          <div className={`grid ${post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'} gap-2 mb-3`}>
            {post.images.map((img, i) => (
              <img
                key={i}
                src={img}
                alt="Post"
                className="rounded-md w-full object-cover"
                style={{ maxHeight: post.images.length === 1 ? '500px' : '250px' }}
              />
            ))}
          </div>
        )}

        {post.videos.length > 0 && (
          <div className="mb-3">
            {post.videos.map((vid, i) => (
              <video
                key={i}
                src={vid}
                controls
                className="rounded-md w-full"
                style={{ maxHeight: '500px' }}
              />
            ))}
          </div>
        )}

        <div className="flex items-center justify-between mt-2 text-sm text-gray-500">
          {post.likes.length > 0 && (
            <div className="flex items-center">
              <div className="flex items-center justify-center bg-[#1877F2] text-white rounded-full p-1 h-5 w-5 mr-1">
                <ThumbsUp className="h-3 w-3" />
              </div>
              {post.likes.length}
            </div>
          )}
          {post.comments.length > 0 && <div>{post.comments.length} comments</div>}
        </div>
      </CardContent>

      <Separator />

      <CardFooter className="p-0">
        <div className="grid grid-cols-2 w-full">
          <Button
            variant="ghost"
            onClick={handleLike}
            className={`flex items-center justify-center py-2 rounded-none ${liked ? 'text-[#1877F2]' : 'text-gray-600'}`}
          >
            <ThumbsUp className={`h-5 w-5 mr-1 ${liked ? 'fill-[#1877F2] text-[#1877F2]' : ''}`} />
            Like
          </Button>
          <Button
            variant="ghost"
            onClick={() => setShowComments(!showComments)}
            className="flex items-center justify-center py-2 rounded-none text-gray-600"
          >
            <MessageSquare className="h-5 w-5 mr-1" /> Comment
          </Button>
        </div>
      </CardFooter>

      {(post.comments.length > 0 || showComments) && (
        <div className="p-4 pt-0">
          <Separator className="my-4" />
          {post.comments.length > 0 && (
            <div className="space-y-3 mb-4">
              {post.comments.map(c => (
                <div key={c.id} className="flex space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{getInitials(c.username)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-gray-100 rounded-lg p-2 px-3">
                      <Link to={`/profile/${c.userId}`} className="font-semibold hover:underline">
                        {c.username}
                      </Link>
                      <p className="text-sm">{c.content}</p>
                    </div>
                    <div className="flex space-x-3 text-xs text-gray-500 mt-1 ml-2">
                      <span>{formatDate(c.createdAt)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {showComments && user && (
            <form onSubmit={handleComment} className="flex space-x-2">
              <Avatar className="h-8 w-8">
                {user.username ? (
                  <AvatarFallback>{getInitials(user.username)}</AvatarFallback>
                ) : null}
              </Avatar>
              <div className="flex-1 flex">
                <Textarea
                  placeholder="Write a comment..."
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  className="flex-1 resize-none min-h-[40px] max-h-[120px] focus-visible:ring-[#1877F2] rounded-full py-2"
                />
                <Button type="submit" size="icon" disabled={!comment.trim()} className="ml-2">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </form>
          )}
        </div>
      )}
    </Card>
  );
}